#!/bin/bash
cd ~/Desktop/client/
python client_app.py
