#install_twisted_rector must be called before importing the reactor
from kivy.support import install_twisted_reactor
install_twisted_reactor()


#A simple Client that send messages to the echo server
from twisted.internet import reactor, protocol

from kivy.uix.image import Image
from kivy.clock import Clock
from os.path import isfile
import time

fnList = [False]

class EchoClient(protocol.Protocol):
	   
	def connectionMade(self):
		print 'connection success'
		self.factory.app.on_connection(self.transport)

	def dataReceived(self, data):
		print 'dataReceived : ', data
		splitdata = data.split(',')
		if len(splitdata) > 1:
			fn = 'client_images/'+splitdata[0]
			order = splitdata[1]
			if order == 'add':
				if isfile(fn):
					fnList.append(fn)
			elif order == 'remove':
				if fn in fnList:
					fnList.remove(fn)
			fnList[0] = True

		if data == 'clear':
			del fnList[:]
			fnList.append(True)
	
class EchoFactory(protocol.ClientFactory):
    protocol = EchoClient
    def __init__(self, app):
        self.app = app

    def clientConnectionLost(self, conn, reason):
		print("connection lost")
		conn.connect()

    def clientConnectionFailed(self, conn, reason):
		print("connection failed")
		time.sleep(10)
		self.clientConnectionLost(conn, reason)


from kivy.app import App
from kivy.uix.label import Label
from kivy.uix.textinput import TextInput
from kivy.uix.floatlayout import FloatLayout
from os.path import isfile

# A simple kivy App, with a textbox to enter messages, and
# a large label to display all the messages received from
# the server
class TwistedClientApp(App):
    connection = None

    def build(self):
		root = self.setup_gui()
		self.connect_to_server()

		def draw(dt):
			if fnList:
				if fnList[0] == True:

					self.layout.clear_widgets()
					for elem in fnList:
						if elem != fnList[0]:
							if isfile(elem):
								img = Image(source = elem, size_hint = (1, 1))
								self.layout.add_widget(img)
					fnList[0] = False
		
		Clock.schedule_interval(draw, 1/30)
		return root

    def setup_gui(self):
        self.layout = FloatLayout()
        return self.layout
		
    def connect_to_server(self):
        reactor.connectTCP('192.168.12.12', 8001, EchoFactory(self))
        # reactor.connectTCP('localhost', 8001, EchoFactory(self))

    def on_connection(self, connection):
        self.connection = connection

    def send_message(self, *args):
        if self.connection:
            self.connection.write('MESSAGE')


if __name__ == '__main__':
    TwistedClientApp().run()
